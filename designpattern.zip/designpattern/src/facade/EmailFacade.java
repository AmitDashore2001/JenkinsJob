package facade;

import singleton.NotificationSingleton;

public class EmailFacade implements NotificationSingleton {

	public void sendNotification(String channel, String subject, String message) {

		System.out.println("Sending Channel" + channel + ": Subject: " + subject + ", Message: " + message);
	}
}
