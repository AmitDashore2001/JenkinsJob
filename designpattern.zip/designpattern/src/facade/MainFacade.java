package facade;

public class MainFacade {
	public static void main(String args[]) {

		// Create a NotificationFacade
		ServiceFacade serviceFacade = new ServiceFacade();

		if (args.length < 3) {
			System.out.println("Please enter full details");
			return;
		}
		
		String channel = args[0];
		String subject = args[1];
		String message = args[2];
		
		// Send an Email notification
		serviceFacade.sendNotification(channel, subject, message);
	}
}
