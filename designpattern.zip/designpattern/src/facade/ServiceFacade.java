package facade;

import singleton.NotificationSingleton;

public class ServiceFacade {
    private NotificationSingleton emailChannel;
    private NotificationSingleton smsChannel;

    public ServiceFacade() {
        // Initialize email and SMS channels
        emailChannel = new EmailFacade();
        smsChannel = new SMSFacade();
    }

    public void sendNotification(String channel, String subject, String message) {
        if ("Email".equalsIgnoreCase(channel)) {
            emailChannel.sendNotification(channel, subject, message);
        } else
     
            smsChannel.sendNotification(channel, subject, message);
        }
        }
    

