package factory;

public class Email implements Notification {

	@Override
	public void sendNotification(String channel, String subject, String message) {

		System.out.println("Sending Channel" + channel + ": Subject: " + subject + ", Message: " + message);
	}
}

