package factory;

public class FactoryNotify {
	
	public static Notification getNotify(String channelType){
		
		if(channelType.trim().equalsIgnoreCase("Email")) {
			return new Email();
		}
		else if(channelType.trim().equalsIgnoreCase("SMS")) {
			return new SMS();
		}
		else
		return null;
	}
}