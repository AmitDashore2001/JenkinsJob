package factory;

import singleton.NotificationService;

public class Main {
	
    public static void main(String args[]) {
	
	Notification n1=FactoryNotify.getNotify("SMS");
	
	if (args.length < 3) {
		System.out.println("Please enter full details");
		return;
	}
	String channel = args[0];
	String subject = args[1];
	String message = args[2];
	
	n1.sendNotification(channel, subject, message);

}
    }
