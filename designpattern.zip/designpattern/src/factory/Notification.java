package factory;

public interface Notification
{
	void sendNotification(String channel,String subject, String message);
}
