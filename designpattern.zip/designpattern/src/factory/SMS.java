package factory;

public class SMS implements Notification {

	@Override
		public void sendNotification(String channel, String subject, String message) {

			System.out.println("Sending Channel" + channel + ": Subject: " + subject + ", Message: " + message);
		}
}