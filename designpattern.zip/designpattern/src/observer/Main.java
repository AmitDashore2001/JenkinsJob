package observer;

public class Main {
	
	public static void main(String args[]) {
	
	NotificationManager nm= new NotificationManager();
	
	 Subscriber amit= new Subscriber();
	 nm.subscribe(amit);
	 nm.notify("Email","Hii", "Hello");
	 nm.unsubscribe(amit);
	 nm.notify("Email", "Oracle", "Java");
	 nm.subscribe(amit);
	 nm.notify("Email", "India", "Virat");
	 
	 Subscriber aashu= new Subscriber();
	 nm.subscribe(aashu);
	 nm.notify("SMS", "Nagarro", "Caring");
	}
}
