package observer;

import java.util.ArrayList;
import java.util.List;

public class NotificationManager implements Subject{

	List<User> subscribers=new ArrayList<>();
	
	@Override
	public void subscribe(User ue) {
		subscribers.add(ue);

	}

	@Override
	public void unsubscribe(User ue) {
		// TODO Auto-generated method stub

		this.subscribers.remove(ue);
	}

	@Override
	public void notify(String channel, String subject, String message) {
		// TODO Auto-generated method stub
		for(User ue: this.subscribers) {
			ue.notified(channel, subject, message);
		}
	}
}
