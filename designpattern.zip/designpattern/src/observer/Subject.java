package observer;

public interface Subject {
	
	void subscribe(User ue);
	void unsubscribe(User ue);
    void notify(String channel, String subject, String message);
}