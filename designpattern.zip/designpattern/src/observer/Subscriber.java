package observer;

public class Subscriber implements User{

	@Override
	public void notified(String channel, String subject, String message) {
		// TODO Auto-generated method stub
		System.out.println("Sending Channel" + channel+ ": Subject: " + subject + ", Message: " + message);
	}
}
