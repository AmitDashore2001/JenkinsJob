package observer;

public interface User {

    void notified(String channel, String subject, String message);
}
