package singleton;

public class MainSingleton {

	public static void main(String args[]) {

		// Simulate sending a notification without command-line arguments
//		        NotificationService notificationService = NotificationService.getInstance();
//		        notificationService.sendNotification("Email", "Hello", "GoodBye");
		if (args.length < 3) {
			System.out.println("Please enter full details");
			return;
		}
		
		String channel = args[0];
		String subject = args[1];
		String message = args[2];

		// Simulate sending a notification based on command-line arguments
		NotificationService notificationService = NotificationService.getInstance();
		notificationService.sendNotification(channel, subject, message);
	}
}
