package singleton;

import factory.Notification;

public class NotificationService {
	    private static NotificationService instance;
	    
	    private NotificationService() {
	        // Private constructor to enforce singleton pattern
	    }
	    
	    public static NotificationService getInstance() {
	        if (instance == null) {
	            instance = new NotificationService();
	        }
	        return instance;
	    }
	    
	    public void sendNotification(String channel, String subject, String message) {
	        System.out.println("Sending Channel" + channel  + " \nsubject: " + subject + "\nMessage: " + message);
	    }
	}
	    

