package singleton;

public interface NotificationSingleton {
	void sendNotification(String channel, String subject, String message);
}
