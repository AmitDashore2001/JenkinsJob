package strategy;

public class ClientNotification {
	
	    public static void main(String[] args) {
	        NotificationContext context = new NotificationContext();

	        // Use EmailNotification strategy
	        context.setStrategy(new EmailNotification());
	        context.send("Hii", "Hello");

	        // Use SMSNotification strategy
	        context.setStrategy(new SMSNotification());
	        context.send("Hii", "Hello");
	    }
	}

