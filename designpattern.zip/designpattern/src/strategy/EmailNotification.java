package strategy;

public class EmailNotification implements Notification {

	@Override
	public void sendNotification(String subject, String message) {

		System.out.println("Sending Email - Subject: " + subject + ", Message: " + message);

	}

}
