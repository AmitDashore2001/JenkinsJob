package strategy;

public interface Notification {

	void sendNotification(String subject, String message);
}
