package strategy;

public class NotificationContext {
	
    private Notification strategy;

	    public void setStrategy(Notification strategy) {
	        this.strategy = strategy;
	    }
	    
	    public void send(String subject, String message) {
	        strategy.sendNotification(subject, message);
	    }
	}
