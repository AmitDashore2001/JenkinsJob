package strategy;

public class SMSNotification implements Notification{

	@Override
	public void sendNotification(String subject, String message) {
		
		System.out.println("Sending SMS - Subject: " + subject + ", Message: " + message);
	}
}
